//Name: Vyshnavi Vijendran
//Student ID: 501164438
//custom exception class
public class AudioContentAlreadyDownloadedException extends RuntimeException{
	public AudioContentAlreadyDownloadedException(){}
	
    public AudioContentAlreadyDownloadedException(String message){
        super(message);
    }
}