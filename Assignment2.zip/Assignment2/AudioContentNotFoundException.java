//Name: Vyshnavi Vijendran
//Student ID: 501164438
//custom exception class
public class AudioContentNotFoundException extends RuntimeException{
	public AudioContentNotFoundException(){}
	
    public AudioContentNotFoundException(String message){
        System.out.print(message);
    }
}