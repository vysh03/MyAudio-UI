Everything in the code works and complies.
BONUS SEARCHP also completed as well.