//Name: Vyshnavi Vijendran
//Student ID: 501164438
//custom exception class
public class NoMatchesFoundException extends RuntimeException{
    public NoMatchesFoundException(){}
	
    public NoMatchesFoundException(String message){
        super(message);
    }

}
