//Name: Vyshnavi Vijendran
//Student ID: 501164438
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// Simulation of audio content in an online store
// The songs, podcasts, audiobooks listed here can be "downloaded" to your library

public class AudioContentStore
{
		private ArrayList<AudioContent> contents;
		private HashMap<String,Integer> findTitle = new HashMap<>();;
		private HashMap<String, ArrayList<Integer>> findArtist = new HashMap<>();;
		private HashMap<String, ArrayList<Integer>> findGenre = new HashMap<>();;
		
		public AudioContentStore() 
		{
			
			try{
			this.contents = new ArrayList<>();
			//add the contents from the file store.txt
			contents.addAll(newFile("store.txt"));

			//set values to hashmap but calling methods
			this.findTitle = createTitle();
			this.findGenre = createGenre();
			this.findArtist = createArtist();
			}

			catch(IOException e){
				System.out.println(e.getMessage());
				System.exit(1);
			}

		}
	
		//create and return the title hashmap
		public HashMap <String,Integer> createTitle(){
			for(int i =0; i <= contents.size()-1; i++){
				findTitle.put(contents.get(i).getTitle(),i);
			}
			return findTitle;

		}

		//create and return the genre hashmap
		public HashMap <String,ArrayList<Integer>> createGenre(){
			//genre
			ArrayList<AudioContent> song = new ArrayList<AudioContent>();

			//if x is a Song then add it to the arraylist
			for(AudioContent x: contents){
				if(x.getType().equals(Song.TYPENAME)){
					song.add(x);
				}
			}

			//declare genre variables
			ArrayList<Integer> pop = new ArrayList<Integer>();
			ArrayList<Integer> rock = new ArrayList<Integer>();
			ArrayList<Integer> jazz = new ArrayList<Integer>();
			ArrayList<Integer> hiphop = new ArrayList<Integer>();
			ArrayList<Integer> rap = new ArrayList<Integer>();
			ArrayList<Integer> classical = new ArrayList<Integer>();

			//go through songs arrayList
			for(int i = 0; i <= song.size()-1;i++){
				//if the genre is POP, add the index to the arrayList pop
				if(((Song)song.get(i)).getGenre().toString().equals("POP")){
					pop.add(contents.indexOf(song.get(i)));
				}
				//if the genre is ROCK, add the index to the arrayList rock
				else if(((Song)song.get(i)).getGenre().toString().equals("ROCK")){
					rock.add(contents.indexOf(song.get(i)));
				}
				//if the genre is JAZZ, add the index to the arrayList jazz
				else if(((Song)song.get(i)).getGenre().toString().equals("JAZZ")){
					jazz.add(contents.indexOf(song.get(i)));
				}
				//if the genre is HIPHOP, add the index to the arrayList hiphop
				else if(((Song)song.get(i)).getGenre().toString().equals("HIPHOP")){
					hiphop.add(contents.indexOf(song.get(i)));
				}
				//if the genre is RAP, add the index to the arrayList rap
				else if(((Song)song.get(i)).getGenre().toString().equals("RAP")){
					rap.add(contents.indexOf(song.get(i)));
				}
				//if the genre is CLASSICAL, add the index to the arrayList classical
				else if(((Song)song.get(i)).getGenre().toString().equals("CLASSICAL")){
					classical.add(contents.indexOf(song.get(i)));
				}
			}

			//add values to hashmap
		    findGenre.put("POP",pop);
			findGenre.put("ROCK",rock);
			findGenre.put("JAZZ",jazz);
			findGenre.put("HIPPOP",hiphop);
			findGenre.put("RAP",rap);
			findGenre.put("CLASSICAL",classical);

			return findGenre;

		}

		//create and return the artist hashmap
		public HashMap <String,ArrayList<Integer>> createArtist(){
			//artist
			ArrayList<AudioContent> song1 = new ArrayList<AudioContent>();
			ArrayList<AudioContent> audio = new ArrayList<AudioContent>();
			ArrayList<String> singer = new ArrayList<String>();
			ArrayList<String> writer = new ArrayList<String>();

			//if given audiocontent is a song, add to song arrayList
			//if it is a audiobook, add it to audio arrayList
			for(AudioContent x: contents){
				if(x.getType().equals(Song.TYPENAME)){
					song1.add(x);
				}
				if(x.getType().equals(AudioBook.TYPENAME)){
					audio.add(x);
				}
			}

			//go through song arrayList and if the singer arraylist doesn't have the artist, add it
			for(int i = 0; i <= song1.size()-1;i++){
				if(!singer.contains(((Song)song1.get(i)).getArtist())){
				String x = (((Song)song1.get(i)).getArtist());
				singer.add(x);
				}
			}

			//go through song arrayList and if the writer arraylist doesn't have the author, add it
			for(int i = 0; i <= audio.size()-1;i++){
				 if(!writer.contains(((AudioBook)audio.get(i)).getAuthor())){
				    String y = ((AudioBook)audio.get(i)).getAuthor();
					writer.add(y);
				}
			}

			//go through singer arrayList and add the index of which each singer occurs to the num arrayList
			for(String x: singer){
				ArrayList<Integer> num = new ArrayList<Integer>();
				for(int i = 0; i <= contents.size()-1; i++){
					if(contents.get(i).getType().equals(Song.TYPENAME)){
						if(((Song)contents.get(i)).getArtist().equals(x)){
							num.add(i);
						}
					}
				}
				//add to hashmap
				findArtist.put(x,num);
			}

			//go through writer arrayList and add the index of which each singer occurs to the num2 arrayList
			for(String y: writer){
				ArrayList<Integer> num2 = new ArrayList<Integer>();
				for(int i = 0; i <= contents.size()-1; i++){
					if(contents.get(i).getType().equals(AudioBook.TYPENAME)){
						if(((AudioBook)contents.get(i)).getAuthor().equals(y)){
							num2.add(i);
						}
				    }
			    }
				//add to hashmap
				findArtist.put(y,num2);
		    }

			return findArtist;
		}

		public void searchTitle(String title){
			//check if the hashmap contains the given key from user, if so print the info
			if(findTitle.containsKey(title)){
				System.out.print(contents.indexOf(contents.get(findTitle.get(title)))+1 +". ");
				contents.get(findTitle.get(title)).printInfo();

			}
			//if key not found
			else{
				throw new NoMatchesFoundException("No matches found for " +title);
			}

		}

		public ArrayList<Integer> searchGenre(String genre){
			
			//hashmap values are an arrayList create an arrayList to store the given value
			ArrayList<Integer> foundG = new ArrayList<Integer>();

			//check if the hashmap contains the given key from user
			if(findGenre.containsKey(genre)){
				foundG = (findGenre.get(genre));
			}

			//if string not found
			else{
				throw new NoMatchesFoundException("No matches found for " +genre);
			}

			return foundG;
			
		}

		public ArrayList<Integer> searchArtist(String artist){

			//hashmap values are an arrayList create an arrayList to store the given value
			ArrayList<Integer> foundA = new ArrayList<Integer>();

			//check if the hashmap contains the given key from user
			if(findArtist.containsKey(artist)){
				foundA = (findArtist.get(artist));
			}

			//if string not found
			else{
				throw new NoMatchesFoundException("No matches for " +artist);
			}

			return foundA;
		}


		public void findPartial(String substring){
			//create arrayList to add the index
			ArrayList<Integer> index = new ArrayList<Integer>();

			//iterate through contents arrayList
			for(int i = 0; i <= contents.size()-1; i++){
				//when type is Song
				if(contents.get(i).getType().equalsIgnoreCase(Song.TYPENAME)){
					Song song = (Song)contents.get(i);
					//see if the substring is in Song
					if(song.getArtist().contains(substring) || song.getAudioFile().contains(substring) || song.getComposer().contains(substring) 
					    || song.getTitle().contains(substring)  || song.getLyrics().contains(substring)){
							index.add(i);
						}
				}
				//when type is AudioBook
				else if(contents.get(i).getType().equalsIgnoreCase(AudioBook.TYPENAME)){
					AudioBook audioBook = (AudioBook)contents.get(i);
					//see if the substring is in audioBook
					if(audioBook.getAudioFile().contains(substring) || audioBook.getAuthor().contains(substring) || audioBook.getNarrator().contains(substring)
					    || audioBook.getId().contains(substring) || audioBook.getTitle().contains(substring)|| audioBook.getChapters().toString().contains(substring)
						||audioBook.getChapters().toString().contains(substring)){
						index.add(i);
					}
	
				 }
				
			}

			//find index arraylist has no elements, it means no matches found for the partial
			if(index.size() == 0){
				throw new NoMatchesFoundException("No matches for " +substring);
			}
				
			//print info
			for(int y: index){
				System.out.print(y+1+ ". ");
				contents.get(y).printInfo();
				System.out.println();
			}

        } 

		public AudioContent getContent(int index)
		{
			if (index < 1 || index > contents.size())
			{
				return null;
			}
			return contents.get(index-1);
		}

		public void listAll()
		{
			for (int i = 0; i < contents.size(); i++)
			{
				int index = i + 1;
				System.out.print(index + ". ");
				contents.get(i).printInfo();
				System.out.println();
			}
		}

		private ArrayList<String> makeHPChapterTitles()
		{
			ArrayList<String> titles = new ArrayList<String>();
			titles.add("The Riddle House");
			titles.add("The Scar");
			titles.add("The Invitation");
			titles.add("Back to The Burrow");
			return titles;
		}

		private ArrayList<String> makeHPChapters()
		{
			ArrayList<String> chapters = new ArrayList<String>();
			chapters.add("In which we learn of the mysterious murders\n"
					+ "in the Riddle House fifty years ago, \n"
					+ "how Frank Bryce was accused but released for lack of evidence, \n"
					+ "and how the Riddle House fell into disrepair. ");
			chapters.add("In which Harry awakens from a bad dream, \n"
					+ "his scar burning, we recap Harry�s previous adventures, \n"
					+ "and he writes a letter to his godfather.");
			chapters.add("In which Dudley and the rest of the Dursleys are on a diet,\n"
					+ "and the Dursleys get letter from Mrs. Weasley inviting Harry to stay\n"
					+ "with her family and attend the World Quidditch Cup finals.");
			chapters.add("In which Harry awaits the arrival of the Weasleys, \n"
					+ "who come by Floo Powder and get trapped in the blocked-off fireplace,\n"
					+ "blast it open, send Fred and George after Harry�s trunk,\n"
					+ "then Floo back to the Burrow. Just as Harry is about to leave, \n"
					+ "Dudley eats a magical toffee dropped by Fred and grows a huge purple tongue. ");
			return chapters;
		}

		
		private ArrayList<String> makeMDChapterTitles()
		{
			ArrayList<String> titles = new ArrayList<String>();
			titles.add("Loomings.");
			titles.add("The Carpet-Bag.");
			titles.add("The Spouter-Inn.");
			return titles;
		}

		private ArrayList<String> makeMDChapters()
		{
			ArrayList<String> chapters = new ArrayList<String>();
			chapters.add("Call me Ishmael. Some years ago�never mind how long precisely�having little\n"
					+ "or no money in my purse, and nothing particular to interest me on shore,\n"
					+ "I thought I would sail about a little and see the watery part of the world.");
			chapters.add("stuffed a shirt or two into my old carpet-bag, tucked it under my arm, \n"
					+ "and started for Cape Horn and the Pacific. Quitting the good city of old Manhatto, \n"
					+ "I duly arrived in New Bedford. It was a Saturday night in December.");
			chapters.add("Entering that gable-ended Spouter-Inn, you found yourself in a wide, \n"
					+ "low, straggling entry with old-fashioned wainscots, \n"
					+ "reminding one of the bulwarks of some condemned old craft.");
			return chapters;
		}

		
		private ArrayList<String> makeSHChapterTitles()
		{
			ArrayList<String> titles = new ArrayList<String>();
			titles.add("");
			titles.add("");
			titles.add("");
			titles.add("");
			return titles;
		}
		
		private ArrayList<String> makeSHChapters()
		{
			ArrayList<String> chapters = new ArrayList<String>();
			chapters.add("The gale tore at him and he felt its bite deep within\n"
					+ "and he knew that if they did not make landfall in three days they would all be dead");
			chapters.add("Blackthorne was suddenly awake. For a moment he thought he was dreaming\n"
					+ "because he was ashore and the room unbelieveable");
			chapters.add("The daimyo, Kasigi Yabu, Lord of Izu, wants to know who you are,\n"
					+ "where you come from, how ou got here, and what acts of piracy you have committed.");
			chapters.add("Yabu lay in the hot bath, more content, more confident than he had ever been in his life.");
			return chapters;
		}
		
		// Podcast Seasons
		private ArrayList<Season> makeSeasons()
		{
			ArrayList<Season> seasons = new ArrayList<Season>();
		  Season s1 = new Season();
		  s1.episodeTitles.add("Bay Blanket");
		  s1.episodeTitles.add("You Don't Want to Sleep Here");
		  s1.episodeTitles.add("The Gold Rush");
		  s1.episodeFiles.add("The Bay Blanket. These warm blankets are as iconic as Mariah Carey's \n"
		  		+ "lip-syncing, but some people believe they were used to spread\n"
		  		+ "smallpox and decimate entire Indigenous communities. \n"
		  		+ "We dive into the history of The Hudson's Bay Company and unpack the\n"
		  		+ "very complicated story of the iconic striped blanket.");
		  s1.episodeFiles.add("There is no doubt that the Klondike Gold Rush was an iconic event. \n"
		  		+ "But what did the mining industry cost the original people of the territory? \n"
		  		+ "And what was left when all the gold was gone? And what is a sour toe cocktail?");
		  s1.episodeFiles.add("here is no doubt that the Klondike Gold Rush was an iconic event. \n"
		  		+ "But what did the mining industry cost the original people of the territory? \n"
		  		+ "And what was left when all the gold was gone? And what is a sour toe cocktail?");
		  s1.episodeLengths.add(31);
		  s1.episodeLengths.add(32);
		  s1.episodeLengths.add(45);
		  seasons.add(s1);
		  Season s2 = new Season();
		  s2.episodeTitles.add("Toronto vs Everyone");
		  s2.episodeTitles.add("Water");
		  s2.episodeFiles.add("There is no doubt that the Klondike Gold Rush was an iconic event. \n"
		  		+ "But what did the mining industry cost the original people of the territory? \n"
		  		+ "And what was left when all the gold was gone? And what is a sour toe cocktail?");
		  s2.episodeFiles.add("Can the foundation of Canada be traced back to Indigenous trade routes?\n"
		  		+ "In this episode Falen and Leah take a trip across the Great Lakes, they talk corn\n"
		  		+ "and vampires, and discuss some big concerns currently facing Canada's water."); 
		  s2.episodeLengths.add(45);
		  s2.episodeLengths.add(50);
		 
		  seasons.add(s2);
		  return seasons;
		}

		private ArrayList<AudioContent> newFile(String fileName) throws FileNotFoundException{
			
			ArrayList<AudioContent> newContent = new  ArrayList<>();
			//create scanner which goes through file
			Scanner scanner = new Scanner(new File(fileName));

			while(scanner.hasNextLine()){
				String type = scanner.nextLine();
				//store into specific variavles if the nextLine is a Song
				if(type.equalsIgnoreCase(Song.TYPENAME)){
					String id = scanner.nextLine();
					String title = scanner.nextLine();
					String year = scanner.nextLine();
					String length = scanner.nextLine();
					String artist = scanner.nextLine();
					String composer = scanner.nextLine();;
					String genre = scanner.nextLine();
					String lyricsNum = scanner.nextLine();
					
					StringBuilder lyrics = new StringBuilder();
					//convert String to int
					int numLyrics = Integer.parseInt(lyricsNum);

					for(int i = 0; i <= numLyrics-1; i++){
						//add lyrics
						lyrics.append(scanner.nextLine()).append("\n"); 
					}

					String file = lyrics.toString();
					//add the song to the AudioContents arrayList
                    newContent.add(new Song(title, Integer.parseInt(year),id,Song.TYPENAME,file,Integer.parseInt(length),artist,composer,Song.Genre.valueOf(genre),file));

				}
				
				//store into specific variavles if the nextLine is a AudioBook
				else if(type.equalsIgnoreCase(AudioBook.TYPENAME)){
					String id = scanner.nextLine();
					String title = scanner.nextLine();
					String year = scanner.nextLine();
					String length = scanner.nextLine();
					String author = scanner.nextLine();
					String narrator = scanner.nextLine();
					String numChapters = scanner.nextLine();

					StringBuilder lyrics = new StringBuilder();
					
					//create title and content arrayList
					ArrayList<String> chapTitles = new ArrayList<String>();
					ArrayList<String> chapContents = new ArrayList<String>();

					//convert String to int
					int numChap = Integer.parseInt(numChapters);

					//get Chapter titles through loop and add to arrayLisr
					for(int i = 0; i <= numChap-1; i ++){
						chapTitles.add(scanner.nextLine());
					}

					//go through each chapter and add the contents
					for(String chap: chapTitles){
						String numLines1 = scanner.nextLine();
					    int numLines = Integer.parseInt(numLines1);

					    for(int i = 0; i <= numLines-1; i++){
						lyrics.append(scanner.nextLine());
					    }
				
						chapContents.add(lyrics.toString());
				}

				//add the AudioBook to the AudioContents arrayList
				newContent.add(new AudioBook(title,Integer.parseInt(year),id,AudioBook.TYPENAME,"",Integer.parseInt(length),author,narrator,chapTitles,chapContents));
			}
			}

			//return the contents
		   return newContent;

	}

}