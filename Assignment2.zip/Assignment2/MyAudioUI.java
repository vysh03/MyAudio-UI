//Name: Vyshnavi Vijendran
//Student ID: 501164438
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;

// Simulation of a Simple Text-based Music App (like Apple Music)

public class MyAudioUI
{
	public static void main(String[] args) throws FileNotFoundException
	{
		// Simulation of audio content in an online store
		// The songs, podcasts, audiobooks in the store can be downloaded to your library
		AudioContentStore store = new AudioContentStore();
		
		// Create my music library
		Library library = new Library();

		Scanner scanner = new Scanner(System.in);
		System.out.print(">");

		// Process keyboard actions
		while (scanner.hasNextLine())
		{
			String action = scanner.nextLine();

			if (action == null || action.equals("")) 
			{
				System.out.print("\n>");
				continue;
			}
			else if (action.equalsIgnoreCase("Q") || action.equalsIgnoreCase("QUIT"))
				return;
			
			else if (action.equalsIgnoreCase("STORE"))	// List all songs
			{
				store.listAll(); 
			}
			else if (action.equalsIgnoreCase("SONGS"))	// List all songs
			{
				library.listAllSongs(); 
			}
			else if (action.equalsIgnoreCase("BOOKS"))	// List all songs
			{
				library.listAllAudioBooks(); 
			}
			else if (action.equalsIgnoreCase("PODCASTS"))	// List all songs
			{
				library.listAllPodcasts(); 
			}
			else if (action.equalsIgnoreCase("ARTISTS"))	// List all songs
			{
				library.listAllArtists(); 
			}
			else if (action.equalsIgnoreCase("PLAYLISTS"))	// List all play lists
			{
				library.listAllPlaylists(); 
			}
			else if (action.equalsIgnoreCase("DOWNLOAD")) 
			{
				int index = 0;
				int end = 0;
				
				//put in rty block if any errors
				try{
					//get inital index
				System.out.print("Store Content #: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
					scanner.nextLine(); // consume nl
				}
				

				//get ending index
				System.out.print("To Store Content #: ");
				if (scanner.hasNextInt())
				{
					end = scanner.nextInt();
					scanner.nextLine();
				}

				// index is greater than the end means unable to download
				if(index > end){
					throw new IndexOutOfBoundsException("Could not download, not valid input");
				}
			}

			//catch error
			catch(IndexOutOfBoundsException e){
				System.out.println(e.getMessage());
			}


			try{
				for(int i = index; i <= end; i++){
					AudioContent content = store.getContent(i);
					try{
						//download content
					library.download(content);
					}

					//catch error if already downloaded
					catch(AudioContentAlreadyDownloadedException e){
						System.out.println(e.getMessage());
					}
				}
			}

			//catch error if Null
			catch(NullPointerException e){
				System.out.println();
				System.out.println(e.getMessage());
			}

	
			}
			else if (action.equalsIgnoreCase("PLAYSONG")) 
			{
				int index = 0;

				try{
				System.out.print("Song Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
				// consume the nl character since nextInt() does not
					scanner.nextLine(); 
				}
				library.playSong(index);
			}

			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
			}


			else if (action.equalsIgnoreCase("BOOKTOC")) 
			{
				int index = 0;
 
				try{
				System.out.print("Audio Book Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
					scanner.nextLine();
				}
				library.printAudioBookTOC(index);
			}
			catch(AudioContentNotFoundException e){
			  System.out.println(e.getMessage());
			}
					
		    }

			else if (action.equalsIgnoreCase("PLAYBOOK")) 
			{
				int index = 0;

				try{
				System.out.print("Audio Book Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
				}
				int chapter = 0;
				System.out.print("Chapter: ");
				if (scanner.hasNextInt())
				{
					chapter = scanner.nextInt();
					scanner.nextLine();
				}
				library.playAudioBook(index, chapter);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
					
			}
			
			else if (action.equalsIgnoreCase("PODTOC")) 
			{
				int index = 0;
				int season = 0;
				try{
				System.out.print("Podcast Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
				}
				System.out.print("Season: ");
				if (scanner.hasNextInt())
				{
					season = scanner.nextInt();
					scanner.nextLine();
				}
				library.printPodcastEpisodes(index, season);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}

			}
			else if (action.equalsIgnoreCase("PLAYPOD")) 
			{
				int index = 0;

				try{
				System.out.print("Podcast Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
					scanner.nextLine();
				}
				int season = 0;
				System.out.print("Season: ");
				if (scanner.hasNextInt())
				{
					season = scanner.nextInt();
					scanner.nextLine();
				}
				int episode = 0;
				System.out.print("Episode: ");
				if (scanner.hasNextInt())
				{
					episode = scanner.nextInt();
					scanner.nextLine();
				}
				library.playPodcast(index, season, episode);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
					
			}
			else if (action.equalsIgnoreCase("PLAYALLPL")) 
			{
				String title = "";

				try{
				System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
				{
					title = scanner.nextLine();
				}
				library.playPlaylist(title);
			}

			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}

			}
			else if (action.equalsIgnoreCase("PLAYPL")) 
			{
				String title = "";
                int index = 0;
        

				try{
				System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
				{
					title = scanner.nextLine();
				}
				System.out.print("Content Number: ");
				if (scanner.hasNextInt())
				{
					index = scanner.nextInt();
					scanner.nextLine();
				}
				library.playPlaylist(title, index);
			}

			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
					
			}
			// Delete a song from the library and any play lists it belongs to
			else if (action.equalsIgnoreCase("DELSONG")) 
			{
				int songNum = 0;

				try{
				System.out.print("Library Song #: ");
				if (scanner.hasNextInt())
				{
					songNum = scanner.nextInt();
					scanner.nextLine();
				}
				
				library.deleteSong(songNum);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
					
			}

			else if (action.equalsIgnoreCase("MAKEPL")) 
			{
				String title = "";

				try{
				System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
				{
					title = scanner.nextLine();
				}
				library.makePlaylist(title);
			}

			catch(AudioContentAlreadyDownloadedException e){
				System.out.println(e.getMessage());
			}

			}
			else if (action.equalsIgnoreCase("PRINTPL"))	// print playlist content
			{
				String title = "";

				try{
				System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
					title = scanner.nextLine();

				library.printPlaylist(title);
				}

				catch(AudioContentNotFoundException e){
					System.out.println(e.getMessage());
				}
					
			}
			// Add content from library (via index) to a playlist
			else if (action.equalsIgnoreCase("ADDTOPL")) 
			{
				int contentIndex = 0;
				String contentType = "";
                String playlist = "";
        
				try{
                System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
					playlist = scanner.nextLine();
        
				System.out.print("Content Type [SONG, PODCAST, AUDIOBOOK]: ");
				if (scanner.hasNextLine())
					contentType = scanner.nextLine();
				
				System.out.print("Library Content #: ");
				if (scanner.hasNextInt())
				{
					contentIndex = scanner.nextInt();
					scanner.nextLine(); // consume nl
				}
				
				library.addContentToPlaylist(contentType, contentIndex, playlist);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}
			}
			// Delete content from play list
			else if (action.equalsIgnoreCase("DELFROMPL")) 
			{
				try{
				int contentIndex = 0;
				String playlist = "";

				System.out.print("Playlist Title: ");
				if (scanner.hasNextLine())
					playlist = scanner.nextLine();
				
				System.out.print("Playlist Content #: ");
				if (scanner.hasNextInt())
				{
					contentIndex = scanner.nextInt();
					scanner.nextLine(); // consume nl
				}
				library.delContentFromPlaylist(contentIndex, playlist);
			}
			catch(AudioContentNotFoundException e){
				System.out.println(e.getMessage());
			}

			}
			else if (action.equalsIgnoreCase("SORTBYYEAR")) // sort songs by year
			{
				library.sortSongsByYear();
			}
			else if (action.equalsIgnoreCase("SORTBYNAME")) // sort songs by name (alphabetic)
			{
				library.sortSongsByName();
			}
			else if (action.equalsIgnoreCase("SORTBYLENGTH")) // sort songs by length
			{
				library.sortSongsByLength();
			}
			else if(action.equalsIgnoreCase("SEARCH")){

				String title = "";
				//ask user to enter title
				System.out.print("Enter title: ");

				if (scanner.hasNextLine()){
					title = scanner.nextLine();
				}

				try{
					//searchTitle in a try block incase no matches
				store.searchTitle(title);
				}
				catch(NoMatchesFoundException e){
					System.out.println(e.getMessage());
				}

			}
			else if(action.equalsIgnoreCase("SEARCHA")){

				//get user input for artist name
				String artist = "";
				System.out.print("Enter Artist Name: ");
				if (scanner.hasNextLine()){
					artist = scanner.nextLine();
				}

				//searchArtist in try block incase no matches
				try{
				ArrayList<Integer> index = store.searchArtist(artist);
				
				for(int x: index){
					//x+1 because the indexes are one behind
					System.out.print((x+1)+ ". ");
					store.getContent(x+1).printInfo();
					System.out.println();
				}
			}

			    catch(NoMatchesFoundException e){
				System.out.println(e.getMessage());
			    }
			}


			else if(action.equalsIgnoreCase("SEARCHG")){

				String genre = "";
				System.out.print("Genre [POP, ROCK, JAZZ, HIPHOP, RAP, CLASSICAL]: ");

				//get user input for genre
				if (scanner.hasNextLine()){
					genre = scanner.nextLine();
				}

				//searchGenre in a try block incase no matches
				try{
				ArrayList<Integer> index = store.searchGenre(genre);
				for(int x: index){
					//x+1 because the indexes are one behind
					System.out.print((x+1)+ ". ");
					store.getContent(x+1).printInfo();
					System.out.println();
				}
			}
			//catch and print error
			catch(NoMatchesFoundException e){
				System.out.println(e.getMessage());
			    }
			}

			else if(action.equalsIgnoreCase("DOWNLOADA")){

				String artist = "";
				//get user input for artist name
				System.out.print("Enter Artist Name: ");
				if (scanner.hasNextLine()){
					artist = scanner.nextLine();
				}

				try{
				ArrayList<Integer> index = store.searchArtist(artist);

				for(int x: index){
					//x+1 because the indexes are one behind
					AudioContent content = store.getContent(x+1);
					//place to try catch blocks incase content already downloaded
					try{
					library.download(content);
					}
					catch(AudioContentAlreadyDownloadedException e){
						System.out.println(e.getMessage());
					}
				}
			}
			//if user entered artist name does not match catch the error
			catch(NoMatchesFoundException e){
				System.out.println(e.getMessage());
			}
			
			}

			else if(action.equalsIgnoreCase("DOWNLOADG")){
				String genre = "";
				System.out.print("Genre [POP, ROCK, JAZZ, HIPHOP, RAP, CLASSICAL]: ");

				//get user input for genre
				if (scanner.hasNextLine()){
					genre = scanner.nextLine();
				}

				try{
				ArrayList<Integer> index = store.searchGenre(genre);
				for(int x: index){
					//x+1 because the indexes are one behind
					AudioContent content = store.getContent(x+1);
					//place to try catch blocks incase content already downloaded
					try{
					library.download(content);
					}
					catch(AudioContentAlreadyDownloadedException e){
						System.out.println(e.getMessage());
					}
				}
			}

			//if user entered genre does not match catch the error
			catch(NoMatchesFoundException e){
				System.out.println(e.getMessage());
			}

			}

			else if(action.equalsIgnoreCase("SEARCHP")){
				String substring = "";
				System.out.print("Partial String: ");

				//get user input of partial string
				if (scanner.hasNextLine()){
					substring = scanner.nextLine();
				}

				try{
				//call the findPartial method in AudioContentStore
				store.findPartial(substring);
				}

				//catach if no matches for enetered string
				catch (NoMatchesFoundException e){
					System.out.println(e.getMessage());
				}
			}

			System.out.print("\n>");
		}
	}
}
