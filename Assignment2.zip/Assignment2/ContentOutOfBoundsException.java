
public class ContentOutOfBoundsException extends RuntimeException{
    public ContentOutOfBoundsException(){}
	
    public ContentOutOfBoundsException(String message){
        super(message);
    }

}
